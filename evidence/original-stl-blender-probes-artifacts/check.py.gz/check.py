import sys,json,time,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/zach/FEA-R')
from backend.stl_io import parse_stl,inspect_triangles,_check_reduction,_clean_reduced
from backend.stl_fidelity import measure_surface
path=Path('/tmp/openfea-blender-reduction/probe.json'); record=json.loads(path.read_text())
source_path=Path('/Users/zach/FEA-R/data/stls/6aece2e705cd44bba3d302755c211625/source.stl')
start=time.monotonic(); source=parse_stl(source_path.read_bytes()); candidate=parse_stl(Path(record['candidate_path']).read_bytes())
source_inspection=inspect_triangles(source)
record['inspection']=inspect_triangles(candidate)
print('TOPOLOGY',record['inspection']['watertight'],record['inspection']['euler_characteristic'],flush=True)
record['relative_volume_change']=abs(record['inspection']['signed_volume_mm3']/source_inspection['signed_volume_mm3']-1)
record['surface_measurement']=measure_surface(source,candidate)
print('SURFACE',record['surface_measurement'],flush=True)
try:
 _check_reduction(source,source_inspection,candidate)
 record['accepted_by_geometry_gates']=True
except ValueError as exc: record.update(accepted_by_geometry_gates=False,error=str(exc))
record['verification_seconds']=time.monotonic()-start
record['source_unchanged']=hashlib.sha256(source_path.read_bytes()).hexdigest()==record['source_sha256']
path.write_text(json.dumps(record,indent=2,default=lambda x:x.item())+'\n')
print(json.dumps(record,default=lambda x:x.item()),flush=True)
