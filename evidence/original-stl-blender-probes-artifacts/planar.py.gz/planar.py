"""Disposable diagnosis only. No production geometry or user Blender scene is modified."""
import bpy, numpy as np, json, hashlib, time
from pathlib import Path
source=Path('/Users/zach/FEA-R/data/stls/6aece2e705cd44bba3d302755c211625/source.stl')
out=Path('/tmp/openfea-blender-reduction')
start=time.monotonic()
raw=source.read_bytes()
count=int.from_bytes(raw[80:84],'little')
record=np.dtype([('normal','<f4',3),('vertices','<f4',9),('attribute','<u2')])
tris=np.frombuffer(raw,dtype=record,count=count,offset=84)['vertices'].reshape(-1,3,3)
points,indices=np.unique(tris.reshape(-1,3),axis=0,return_inverse=True)
mesh=bpy.data.meshes.new('diagnostic-original')
mesh.vertices.add(len(points)); mesh.vertices.foreach_set('co',points.ravel())
mesh.loops.add(len(indices)); mesh.loops.foreach_set('vertex_index',indices)
mesh.polygons.add(count); mesh.polygons.foreach_set('loop_start',np.arange(count,dtype=np.int32)*3)
mesh.polygons.foreach_set('loop_total',np.full(count,3,dtype=np.int32)); mesh.update()
obj=bpy.data.objects.new('diagnostic-original',mesh); bpy.context.collection.objects.link(obj)
modifier=obj.modifiers.new('diagnostic-planar','DECIMATE'); modifier.decimate_type='DISSOLVE'
modifier.angle_limit=np.deg2rad(.1); modifier.use_dissolve_boundaries=False
print('SOURCE_LOADED',count,len(points),flush=True)
evaluated=obj.evaluated_get(bpy.context.evaluated_depsgraph_get()); candidate=evaluated.to_mesh()
candidate.calc_loop_triangles()
vertices=np.empty((len(candidate.vertices),3),np.float32); candidate.vertices.foreach_get('co',vertices.ravel())
faces=np.empty((len(candidate.loop_triangles),3),np.int32); candidate.loop_triangles.foreach_get('vertices',faces.ravel())
t=vertices[faces]
recs=np.zeros(len(t),dtype=record); recs['vertices']=t.reshape(-1,9)
path=out/'blender-planar-01deg.stl'; path.write_bytes(b'OpenFEA rejected-or-unverified diagnostic'.ljust(80,b' ')+len(t).to_bytes(4,'little')+recs.tobytes())
result={'scope':'Experimental geometry only; not adopted or accepted for meshing.', 'blender':bpy.app.version_string,'source_sha256':hashlib.sha256(raw).hexdigest(),'source_triangles':count,'options':{'decimate_type':'DISSOLVE','angle_limit_rad':modifier.angle_limit,'use_dissolve_boundaries':False},'candidate_path':str(path),'candidate_triangles':len(t),'candidate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.monotonic()-start}
(out/'planar-probe.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result),flush=True)
evaluated.to_mesh_clear()
