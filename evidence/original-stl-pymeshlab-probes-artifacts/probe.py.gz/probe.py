"""Isolated diagnostics: never install candidates in the production data directory."""
from pathlib import Path
import sys,os,time,json,hashlib,importlib.metadata
sys.path.insert(0,'/tmp/openfea-pymeshlab-probe/dependencies')
sys.path.insert(0,'/Users/zach/FEA-R')
import numpy as np,pymeshlab
from backend.stl_io import parse_stl,inspect_triangles,write_binary_stl,_check_reduction
from backend.stl_fidelity import measure_surface
from scripts.validate_original_stl import write_record
from datetime import datetime,timezone
out=Path('/tmp/openfea-pymeshlab-probe')
source=Path('/Users/zach/FEA-R/data/stls/6aece2e705cd44bba3d302755c211625/source.stl')
raw=source.read_bytes();tris=parse_stl(raw);inspection=inspect_triangles(tris)
_,first,inverse=np.unique(np.round(tris.reshape(-1,3),7),axis=0,return_index=True,return_inverse=True)
vertices=tris.reshape(-1,3)[first];faces=inverse.reshape(-1,3)
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Original private source; diagnostics only, no CAD/physical ground truth, no production adoption or FEA acceptance.','source_sha256':hashlib.sha256(raw).hexdigest(),'source_bytes':len(raw),'source_inspection':inspection,'pymeshlab_version':importlib.metadata.version('pymeshlab'),'source_hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ('backend/stl_io.py','backend/stl_fidelity.py')},'cases':[]}
options=dict(targetfacenum=80000,targetperc=0,qualitythr=.3,preserveboundary=True,boundaryweight=1.0,preservenormal=True,preservetopology=True,planarquadric=False,planarweight=.001,qualityweight=False,autoclean=True,selected=False)
write_record(out/'result.json',record)
for name,placement in [('preserve-topology-normal',True),('original-vertex-placement',False)]:
 start=time.monotonic();settings={**options,'optimalplacement':placement}
 row={'name':name,'options':settings,'adopted':False};record['cases'].append(row)
 print('START',name,flush=True)
 try:
  meshset=pymeshlab.MeshSet();meshset.add_mesh(pymeshlab.Mesh(vertex_matrix=vertices,face_matrix=faces))
  row['effective_defaults']=meshset.filter_parameter_values('meshing_decimation_quadric_edge_collapse',**settings)
  meshset.meshing_decimation_quadric_edge_collapse(**settings)
  mesh=meshset.current_mesh();candidate=mesh.vertex_matrix()[mesh.face_matrix()].astype(np.float32).astype(np.float64)
  target=out/(name+'.stl');write_binary_stl(target,candidate)
  candidate=parse_stl(target.read_bytes());row.update(candidate_path=str(target),candidate_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),candidate_triangles=len(candidate),reduction_seconds=time.monotonic()-start)
  row['inspection']=inspect_triangles(candidate);row['relative_volume_change']=abs(row['inspection']['signed_volume_mm3']/inspection['signed_volume_mm3']-1)
  print('REDUCED',name,len(candidate),row['inspection']['watertight'],row['relative_volume_change'],flush=True)
  write_record(out/'result.json',record)
  if len(candidate)<=80000:
   row['surface_measurement']=measure_surface(tris,candidate)
   print('SURFACE',name,row['surface_measurement'],flush=True)
  _check_reduction(tris,inspection,candidate)
  row['accepted_by_geometry_gates']=True
 except Exception as exc:
  row.update(accepted_by_geometry_gates=False,error=type(exc).__name__+': '+str(exc))
 row['seconds']=time.monotonic()-start
 record['source_unchanged']=hashlib.sha256(source.read_bytes()).hexdigest()==record['source_sha256']
 write_record(out/'result.json',record)
 print('FINISH',name,row.get('accepted_by_geometry_gates'),row.get('error',''),flush=True)
