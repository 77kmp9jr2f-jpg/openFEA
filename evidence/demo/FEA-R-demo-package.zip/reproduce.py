from pathlib import Path
import os, shutil, sys, json
root=Path(__file__).resolve().parent
os.environ['FEAR_DATA_DIR']=str(root/'reproduced')
sys.path.insert(0,str(root/'source'))
from backend.schemas import Analysis
from backend.solver import solve_model
target=root/'reproduced'/'models'/'f5f0cb3a22034e0f8b67f1b4733b5573'
shutil.copytree(root/'model',target,dirs_exist_ok=True)
original=json.loads((root/'result.json').read_text())
result=solve_model(Analysis.model_validate(original['setup']))
print(json.dumps({k:result[k] for k in ('id','peak_von_mises_mpa','max_displacement_mm','force_balance_error_n')},indent=2))
