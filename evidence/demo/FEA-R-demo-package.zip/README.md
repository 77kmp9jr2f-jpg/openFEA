# FEA-R run af02566402df43b2b0125ff688188e74

This archive is a simulation snapshot, not certification. Read report.pdf or report.html.
All lengths are mm, forces N, stresses MPa. The JSON setup is the authoritative input.
The NPZ retains all quadratic DOFs and quadrature stresses; CSV/viewport values sample mesh vertices.
Reference annotations are in result.json > setup > annotations (normalized coordinates).

## Reproduce the solve

Use Python 3.12 and a virtual environment; install source/requirements.txt.
From the archive root run: python reproduce.py
This reuses the original tetrahedra, material and face definitions; it does not remesh.
Compare numeric values with the supplied result.json using floating-point tolerances.
The new run ID and runtime will differ. Source is GPL-3.0-or-later; see the FEA-R repository.
