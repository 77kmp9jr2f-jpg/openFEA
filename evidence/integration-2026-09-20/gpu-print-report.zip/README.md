# OpenFEA run 4d162ab8d809467ea43bf764c5c8479a

This archive is a simulation snapshot, not certification. Read report.pdf or report.html.
All lengths are mm, forces N, stresses MPa. The JSON setup is the authoritative input.
The NPZ retains all displacement DOFs and quadrature stresses; CSV/viewport values sample mesh vertices.
Reference annotations are in result.json > setup > annotations (normalized coordinates).
The interview transcript is in interview.json; an applied Astra setup is in setup-proposal.json when present.

## Reproduce the solve

Use Python 3.12 and a virtual environment; install source/requirements.txt.
From the archive root run: python reproduce.py
This reuses the original tetrahedra, material and face definitions; it does not remesh.
Compare numeric values with the supplied result.json using floating-point tolerances.
The new run ID and runtime will differ. Source is GPL-3.0-or-later; see the OpenFEA repository.
