from pathlib import Path
import os, shutil, sys, json
root=Path(__file__).resolve().parent
os.environ['FEAR_DATA_DIR']=str(root/'reproduced')
sys.path.insert(0,str(root/'source'))
from backend.schemas import Analysis
from backend.solver import solve_model
target=root/'reproduced'/'models'/'9737ceeb435f40c6855ecef6bacf518a'
shutil.copytree(root/'model',target,dirs_exist_ok=True)
original=json.loads((root/'result.json').read_text())
if original['setup'].get('setup_proposal_id'):
    shutil.copyfile(root/'setup-proposal.json',root/'reproduced'/'setup_proposals'/(original['setup']['setup_proposal_id']+'.json'))
result=solve_model(Analysis.model_validate(original['setup']), reproduction_element_order=original.get('element_order', 2))
print(json.dumps({k:result[k] for k in ('id','peak_von_mises_mpa','max_displacement_mm','force_balance_error_n')},indent=2))
