from pathlib import Path
import sys,json,hashlib,time
from datetime import datetime,timezone
sys.path.insert(0,str(Path.cwd()))
from backend.assistant import ask_astra
from backend.schemas import AssistantRequest,Geometry,Material,PrintSettings
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Live production Astra transport on preserved synthetic print runs, with deliberately different draft settings. No geometry, setup, study or run is changed; no new solve or physical validation.','source_sha256':hashlib.sha256(Path('backend/assistant.py').read_bytes()).hexdigest(),'cases':[]}
for label,rid in [('current-contours','12f9942450724ed1876b14254905a847'),('historical-box','4d162ab8d809467ea43bf764c5c8479a')]:
 path=Path('data/runs')/rid/'result.json';raw=path.read_bytes();run=json.loads(raw)
 model=json.loads((Path('data/models')/run['model_id']/'model.json').read_text())
 req=AssistantRequest(message='For this saved run only, explain how wall and skin volumes were estimated, which infill density belongs to it, and whether support material is included. Do not propose changes.',stage='results',run_id=rid,model_id=run['model_id'],geometry=Geometry.model_validate(model['spec']),material=Material.model_validate(run['setup']['material']),fixed_faces=run['setup']['fixed_faces'],loads=run['setup']['loads'],print=PrintSettings(enabled=True,infill_density=.9,rotation_deg=(90,0,0)))
 row={'case':label,'run_id':rid,'request':req.model_dump(mode='json'),'recorded_print':run.get('print'),'run_sha256':hashlib.sha256(raw).hexdigest()}
 record['cases'].append(row);start=time.monotonic()
 try:row['response']=ask_astra(req)
 except Exception as exc:row['error']=type(exc).__name__+': '+str(exc)
 row['seconds']=time.monotonic()-start;row['run_unchanged']=hashlib.sha256(path.read_bytes()).hexdigest()==row['run_sha256']
 Path('/tmp/openfea-astra-print-live.json').write_text(json.dumps(record,indent=2)+'\n')
 print(label,json.dumps(row.get('response',row.get('error'))),flush=True)
